import { BotConfigurations } from '../../../config/Configurations';
import { BIBotConnector } from './BIBotConnector';
import { IChatConnectorSettings, UniversalBot, IBotStorage, MemoryBotStorage, Session, IAddress, BotConnectorBot, ChatConnector } from 'botbuilder';
import { AzureTableClient, AzureBotStorage } from 'botbuilder-azure';
import { BISMController } from '../../controller/BISMController';
import { PorpertiesUtil } from '../../../util/PropertiesUtil';
import { ServerHandler } from '../../../middleware/ServerHandlers';
import { TranslationService } from '../../service/TranslationService';
import { LuisConfiguration } from '../luis/LuisConfiguration';
import { BIDialogs } from '../dialogs/BIDialogs';
let timeout = require('botbuilder-timeout');


export class BIBotConnectorService {
    static logger = ServerHandler.getLogger();
    private static instance: BIBotConnectorService;
    private bot: UniversalBot;
    private connector: BIBotConnector;

    public static getInstance(): BIBotConnectorService {
        if (this.instance == null) {
            this.instance = new BIBotConnectorService();
        }
        return this.instance;
    }

    constructor() {
        this.bot = this.getBotInstance();
    }

    public getBot(): UniversalBot {
        return this.bot;
    }

    public getBotConnector(): BIBotConnector {
        return this.connector;
    }

    private getConnectorSettings(): IChatConnectorSettings {

        let botConfig = BotConfigurations.getBotConfig();

        console.log("authentication.Id:", botConfig.authentication.Id);
        console.log("authentication.password:", botConfig.authentication.password);
        let settings: IChatConnectorSettings = {
            appId: botConfig.authentication.Id,
            appPassword: botConfig.authentication.password
        }
        return settings;
    }

    private getBotInstance(): UniversalBot {
        this.connector = new BIBotConnector(this.getConnectorSettings());
        return new UniversalBot(this.connector);
    }

    private getBotStorage(): IBotStorage {
        let storage: IBotStorage;
        let botConfig = BotConfigurations.getBotConfig();
        if (process.env.NODE_ENV !== "production") {
            storage = new MemoryBotStorage();
        } else {
            const tableClient = new AzureTableClient(
                botConfig.botStorage.tableName,
                botConfig.botStorage.accountName,
                botConfig.botStorage.accountKey
                );
            storage = new AzureBotStorage({ gzipData: false }, tableClient);
        }
        return storage;
    }

    private setBotTimeOut(bot: UniversalBot) {
        let options = {
            PROMPT_IF_USER_IS_ACTIVE_MSG: "Hey are you there?",
            PROMPT_IF_USER_IS_ACTIVE_BUTTON_TEXT: "Yes I am",
            PROMPT_IF_USER_IS_ACTIVE_TIMEOUT_IN_MS: 1800000,
            END_CONVERSATION_MSG: "Conversation Ended",
            END_CONVERSATION_TIMEOUT_IN_MS: 120000
        };
        timeout.setConversationTimeout(bot, options);
    }

    private logUserConversation(event: any) {
        BIBotConnectorService.logger.info('message: ' + event.text + ', user: ', event);
        BIBotConnectorService.logger.info(event);
    }

    private receiveUseConversation(event: any, next: any) {
        this.logUserConversation(event);
        next();
    }
    private sendUseConversation(event: any, next: any) {
        //BIBotConenctorService.logUserConversation(event);
        next();
    }

    public initBot() {
        //let bot = this.getBotInstance();
        let storage = this.getBotStorage();
        this.bot.set('storage', storage);
        this.setBotTimeOut(this.bot);
        this.bot.set('localizerSettings', { defaultLocale: "en" });

        this.bot.on('event', function (message) {
            if (message.name == 'requestWelcomeDialog') {
                var iAddress: IAddress = message.address;
                this.bot.loadSession(iAddress,(error: any, session: Session) => {
                    //       session.beginDialog('BISM:Greeting');
                });
            }
        });

        this.bot.use({
            botbuilder: this.initializeBotBuilder,
            send: function (event, next) {
                BIBotConnectorService.logger.info(event.address + '######');
                next();
            }
        });
        LuisConfiguration.configureLuis(this.bot);
        BIDialogs.registerDialogs(this.bot);
    }



    async initializeBotBuilder(session: Session, next: Function) {
    BIBotConnectorService.logger.info("Entered : BIBotConnectorService: [initializeBotBuilder]")
    let self = this;
    session.userData.userID = session.message.user.id;
    //session.userData.userID = "christian.jacka@boehringer-ingelheim.com";
    if (!session.privateConversationData.countryDetailsSupport && !session.privateConversationData.languageDetailsSupport) {
        let userData = await BISMController.getPreferedLanguage(session.userData.userID, session);
        var userCountryDetails: any = PorpertiesUtil.getJSONPropertiesWithoutSession("BI_supportedCountriesList." + userData.country);
        BIBotConnectorService.logger.debug(" userCountryDetails:BIBotConnectorService :[initializeBotBuilder]", userCountryDetails);
        var userLanguageDetails: any = PorpertiesUtil.getJSONPropertiesWithoutSession("BI_supportedLanguagesList." + userData.language);
        BIBotConnectorService.logger.debug(" userLanguageDetails:BIBotConnectorService:[initializeBotBuilder]", userLanguageDetails);
        if (userCountryDetails.support) {
            if (userLanguageDetails.support) {
                setPrivateConversationData(session, userData.language, userData, userCountryDetails, userLanguageDetails);
            } else {
                session.replaceDialog("BISM:NotSupported", userLanguageDetails.name);
                userLanguageDetails = { code: 'en', name: 'English', nativeName: 'English', support: true }
                setPrivateConversationData(session, 'en', userData, userCountryDetails, userLanguageDetails);
            }
        }
        else {
            session.privateConversationData.countryDetailsSupport = false;
            next();
        }
    }

    if (session.privateConversationData.translationSupport == true) {
        if (PorpertiesUtil.translationSupport(session.privateConversationData.preferredLanguage)) {
            let ts = TranslationService.getInstance();
            let msg = JSON.stringify([{ 'Text': session.message.text }])
            ts.translateTextV3(msg, next, "en").then((response) => {
                session.privateConversationData.translationBeforeMessage = session.message.text;
                BIBotConnectorService.logger.info("Entered  : BIBotConnectorService: [translateTextV3]")
                session.message.text = response;
                next();
            });
        }
        else { next(); }
    }
    else if (session.privateConversationData.countryDetailsSupport == true && session.privateConversationData.translationSupport == false) {
        next();
    }

}
}

function setPrivateConversationData(session: Session, locale: string, userData: any,
    userCountryDetails: any, userLanguageDetails: any) {
    session.privateConversationData.setPreferredLocale = "Yes";
    session.privateConversationData.preferredLocale = locale;
    session.privateConversationData.userID = session.userData.userID;
    session.privateConversationData.preferredLanguage = locale;
    session.privateConversationData.isPreferredLanguageSet = "Yes";
    session.privateConversationData.countryDetailsName = userCountryDetails.name;
    session.privateConversationData.countryDetailsCode = userCountryDetails.code;
    session.privateConversationData.countryDetailsSupport = userCountryDetails.support;
    session.privateConversationData.languageDetailsCode = userLanguageDetails.code;
    session.privateConversationData.languageDetailsName = userLanguageDetails.name;
    session.privateConversationData.languageDetailsNativeName = userLanguageDetails.nativeName;
    session.privateConversationData.languageDetailsSupport = userLanguageDetails.support;
    session.privateConversationData.translationSupport = true

}

