import { UniversalBot, LuisRecognizer, IntentDialog, Session } from 'botbuilder';
import { ServerHandler } from '../../../middleware/ServerHandlers';
import { BotConfigurations } from '../../../config/Configurations';
import { Properties } from 'ts-json-properties';
import { PorpertiesUtil } from "../../../util/PropertiesUtil";

export class LuisConfiguration {

    static logger = ServerHandler.getLogger();
    public static initializeOnScore(score: number, session: Session, intent: string, args: any) {
        LuisConfiguration.logger.info("Entered : LuisConfiguration: [initializeOnScore] ");
        LuisConfiguration.logger.debug("score: LuisConfiguration:[initializeOnScore] ", score);
        session.privateConversationData.translationSupport = false;
        if (session.privateConversationData.countryDetailsSupport) {
            if (score >= 0.50) {
                LuisConfiguration.logger.info("Entered : LuisConfiguration: [initializeOnScore]>0.50 ");
                session.beginDialog(intent, args);
            }
            else {
                LuisConfiguration.logger.info("Entered : LuisConfiguration: [initializeOnScore]<0.50 ");
                args.intent = "BISM:Knowledge.Articles";
                session.beginDialog("BISM:Knowledge.Articles", args);
            }
        }
        LuisConfiguration.logger.info("Exit : LuisConfiguration: [initializeOnScore] ");
    }

    public static initDialog(intent: string, session: Session, args: any) {
        LuisConfiguration.logger.info("Entered : LuisConfiguration: [initDialog] ");
        LuisConfiguration.logger.debug("score: LuisConfiguration:[initializeOnScore] ", args.score);
        if (!session.privateConversationData.countryDetailsSupport) {
            session.send('Sorry! The Chat Service is not available in your region at the moment.');
            session.endDialog('Check out the MySupport [http://mysupport] page to look for support alternatives.')
            return;
        }
        else {
            LuisConfiguration.initializeOnScore(args.score, session, intent, args);
        }
        LuisConfiguration.logger.info("Exit : LuisConfiguration: [initDialog] ");
    }




    public static configureLuis(bot: UniversalBot) {
        console.log(BotConfigurations.getLuisAppUrl());
        let recognizer = new LuisRecognizer(BotConfigurations.getLuisAppUrl());
        let intents = new IntentDialog({ recognizers: [recognizer] })
            .matches('BISM:ask.CallId',(session, args) => {
            session.beginDialog("BISM:ask.CallId", args);
        })
            .matches('BISM:ask.MoreInformation',(session, args) => {
            session.beginDialog("BISM:ask.MoreInformation", args);
        })
            .matches('BISM:ask.Status',(session, args) => {
            session.beginDialog("BISM:ask.Status", args);
        })
            .matches('BISM:MyShop.ReqStatus',(session, args) => {
            this.initDialog("BISM:MyShop.ReqStatus", session, args);
        })
            .matches('BISM:access.system',(session, args) => {
            this.initDialog("BISM:access.system", session, args);
        })
            .matches('BISM:ERP.AccountIssue',(session, args) => {
            this.initDialog("BISM:SAPCreateTicket", session, args);
        })
            .matches('BISM:Question.AboutBot',(session, args) => {
            session.beginDialog("BISM:Question.AboutBot", args);
        })
            .matches('BISM:Questions.Gamification',(session, args) => {
            this.initDialog("BISM:Questions.Gamification", session, args);
        })
        //     .matches('BISM:outlook.distributionlist',(session, args) => {
        //     this.initDialog("BISM:outlook.distributionlist", session, args);
        // })
        //     .matches('BISM:outlook.filesize',(session, args) => {
        //     this.initDialog("BISM:outlook.filesize", session, args);
        // })
            .matches('BISM:BI.Knowledgebase.Hardware.Issue',(session, args) => {
            this.initDialog("BISM:Knowledge.Articles", session, args);
        })
            .matches('BISM:BI.Knowledgebase.Network',(session, args) => {
            this.initDialog("BISM:Knowledge.Articles", session, args);
        })
            .matches('BISM:BI.Knowledgebase.Software.Issue',(session, args) => {
            this.initDialog("BISM:Knowledge.Articles", session, args);
        })
            .matches('BISM:sd.my.tickets',(session, args) => {
            this.initDialog("BISM:My.Ticket", session, args);
        })
            .matches('BISM:sd.update.ticket',(session, args) => {
            this.initDialog("BISM:Update.Ticket", session, args);
        })
            .matches('BISM:sd.close.ticket',(session, args) => {
            this.initDialog("BISM:Close.Ticket", session, args);
        })
            .matches('BISM:System.Issue',(session, args) => {
            this.initDialog("BISM:System.Issue", session, args);
        })
            .matches('BISM:qna.visitor.site.register',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.activedirectory.getmember',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.outlook.access.external',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.myshop.order.status',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.link.create',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.hw.return',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.folder.structure',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.data.share.internal',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.software.install',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.data.share.external',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.network.connectivity.external',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.shareroom.training',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.data.externalemployee.update',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.presentation.corporate.images',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.activedirectory.managemembers',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.outlook.distributionlist',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.skype.image',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.presentation.projector.screen',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.visitor.internet.access',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:qna.system.access',(session, args) => {

            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .matches('BISM:Greeting',(session, args) => {
            this.initDialog("BISM:Greeting", session, args);
        })
            .matches('BISM:qna.outlook.permission.servicemailbox',(session, args) => {
            this.initDialog("BISM:Qna.Dialog", session, args);
        })
            .onDefault((session, args) => {
            session.privateConversationData.translationSupport = false;
            if (!session.privateConversationData.countryDetailsSupport) {
                session.send('Sorry! The Chat Service is not available in your region at the moment.');
                session.send('Check out the MySupport [http://mysupport] page to look for support alternatives.')
                return;
            }
            else {
                LuisConfiguration.logger.info("Entered :[Default Dialog]");
                args.intent = "BISM:Knowledge.Articles"
                session.beginDialog("BISM:Knowledge.Articles", args);
            }
        });
        bot.dialog('/', intents);
    }
}
