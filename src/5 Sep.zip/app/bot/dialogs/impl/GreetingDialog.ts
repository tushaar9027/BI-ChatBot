import { ServerHandler } from '../../../../middleware/ServerHandlers';
import { IDialogWaterfallStep, Session, Library } from 'botbuilder';
import { BIBotConnector } from '../../connector/BIBotConnector';
import { PorpertiesUtil } from '../../../../util/PropertiesUtil';
export class GreetingDialog {
    static logger = ServerHandler.getLogger();

    public static init(library: Library) {
        library.dialog("Greeting", GreetingDialog.getDialog()).triggerAction({
            matches: ["BISM:Greeting", "Greeting"]
        });
    }
    private static getDialog(): IDialogWaterfallStep[] {
        return [
            async(session: Session, args) => {
                GreetingDialog.logger.info("inside greeting dlg :", session.privateConversationData.userDetails);
                if(PorpertiesUtil.translationSupport(session.privateConversationData.preferredLanguage)) {
                    session.message.text = session.privateConversationData.translationBeforeMessage;
                }// Added by Yashi for Hi Sam Dialog---->
                //session.send(BIBotConnector.channelDataMessage(session, session.message.text, false, "", "", "", "ignoringInput").toMessage());
                PorpertiesUtil.tranlationFlagCleaner(session);  
                session.send(BIBotConnector.channelDataMessage(session, PorpertiesUtil.getJSONProperties(session, "bismLanguage.greetingDlg"), false, "", "", "", "ignoringInput").toMessage()).endDialog();  
            }
        ]
    }
}