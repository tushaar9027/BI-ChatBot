import { ServerHandler } from "../../../../middleware/ServerHandlers";
import { IDialogWaterfallStep, Session, IDialogResult, IFindMatchResult, Prompts, Library } from 'botbuilder';
import { BIBotConnector } from "../../connector/BIBotConnector";
import { PorpertiesUtil } from "../../../../util/PropertiesUtil";

export class GamificationDialog {
    static logger = ServerHandler.getLogger()

    public static init(library: Library) {
        library.dialog("Questions.Gamification", GamificationDialog.getDialog()).triggerAction({
            matches: ["BISM:Questions.Gamification", "do I need an umbrella today?"]
        });
    }
    private static getDialog(): IDialogWaterfallStep[] {
        return [
            (session: Session, args: any) => {
                GamificationDialog.logger.info("Entered : GamificationDialog :[BISM:Questions.Gamification] ")
                if (PorpertiesUtil.translationSupport(session.privateConversationData.preferredLanguage)) {
                    session.message.text = session.privateConversationData.translationBeforeMessage;
                }
                PorpertiesUtil.tranlationFlagCleaner(session);
                session.send(BIBotConnector.channelDataMessage(session, PorpertiesUtil.getJSONProperties(session, "bismLanguage.questionsGamificationDialog.weatherMsg")
                    , false, "", "", "", "ignoringInput").toMessage());
                Prompts.text(session, BIBotConnector.channelDataMessage(session, PorpertiesUtil.getJSONProperties(session, "bismLanguage.askMoreInformationDialog.thank_msg"), true, "", "", "", "ignoringInput").toMessage());
                GamificationDialog.logger.info("Exit : GamificationDialog :[BISM:Questions.Gamification] ")
            }
        ]
    }

}